import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import {connect} from 'react-redux';
import {actionCreators} from './redux/actions/MeineActions';

//Mein Button mit als import SemanticUI
import ButtContainer  from './MeinButton';


class Startseite extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Das ist die Startseite</h1>
        </header>
        <p className="App-intro">
          Hier ist einfach nur ein Text.
        </p>
  
          <ButtContainer/>

      </div>
    );
  }
}

function mapStateToProps (state) {

  return {farbe: state.farbe}
}
export const AppContainer = connect(mapStateToProps, actionCreators)(Startseite);


export default Startseite;
