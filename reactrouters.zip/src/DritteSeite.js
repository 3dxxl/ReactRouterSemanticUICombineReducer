import React, { Component } from 'react';

class DritteSeite extends Component {


    render() {


        return (

                <div>
                    <h1>Das ist die dritte Seite</h1>
                
                </div>


        );
    }
}

export default DritteSeite;