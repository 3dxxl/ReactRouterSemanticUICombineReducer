/* import {initialState} from '../MeinStore';


export const reducer = (state = initialState, action) => {
	switch (action.type) {
    
			case "CHANGE_COLORinBlue":
					return {
							...state,
							farbe: "blue"
					};

			case "CHANGE_COLORinRed":
					return {
							...state,
							farbe: "red"
					};

			case "CHANGE_Schrift":
					return {
							...state,
							schriftNav: "Verdana"
					};

			case "CHANGE_SchriftZurück":
					return {
							...state,
							schriftNav: "Times New Roman"
					};
			

			default:
					return state
	}
} */