//React
import React, {Component} from 'react'

//redux
import {connect} from 'react-redux';
import { actionCreators } from './redux/actions/MeineActions';


//Semantic UI
import { Button } from 'semantic-ui-react'

class ButtonExampleColored extends Component {


    

    render() {
        return(

            <div>
            <Button color='red'
            onClick={this.props.nameOffTheAction}
            >Red</Button>
            <h1 style={{color:this.props.farbe}}>Press Button to Change Text Color</h1>
            </div>

        );
    }
}

function mapStateToProps(state) {
    return {farbe: state.farbe}
}

export const ButtContainer = connect(mapStateToProps, actionCreators)(ButtonExampleColored);

export default ButtonExampleColored;
  
  