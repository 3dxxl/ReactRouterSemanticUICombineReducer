import React, { Component } from 'react';

class ZweiteSeite extends Component {


    render() {


        return (

                <div>
                    <h1>Das ist die zweite Seite</h1>
                
                </div>


        );
    }
}

export default ZweiteSeite;