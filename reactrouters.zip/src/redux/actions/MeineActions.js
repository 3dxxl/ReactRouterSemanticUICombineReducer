export const actionCreators = { 
	nameOffTheAction: (event) => {
		return {type: "CHANGE_COLORinBlue"};
	},

	nameOffTheActionZwei: (event) => {
		return {type: "CHANGE_COLORinRed"};
	},
	nameOffTheActionDrei: (event) => {
		return {type: "CHANGE_Schrift"};
	},
	nameOffTheActionVier: (event) => {
		return {type: "CHANGE_SchriftZurück"};
	},
	
	
}