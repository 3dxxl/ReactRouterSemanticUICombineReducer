export const actionCreators = { 
	nameOffTheAction: (event) => {
		return {type: "CHANGE_COLORinBluew"};
	},

	nameOffTheActionZwei: (event) => {
		return {type: "CHANGE_COLORinRed"};
	}
	
	
}